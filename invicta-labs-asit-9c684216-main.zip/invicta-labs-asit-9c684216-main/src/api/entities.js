import { base44 } from './base44Client';


export const Module = base44.entities.Module;

export const Lesson = base44.entities.Lesson;

export const Badge = base44.entities.Badge;



// auth sdk:
export const User = base44.auth;